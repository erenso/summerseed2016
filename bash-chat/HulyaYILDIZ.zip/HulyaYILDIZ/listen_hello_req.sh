#ifconfig komutu ile IP adresimizi sorguladik
MYIP=$(ifconfig|grep "Bcast:"|cut -d ':' -f2|cut -d ' ' -f1)
MYNICK="HLYYLDZ"

# Requestler dinlenir, cevap geldiginde IP ve nick kaydedilir(kayitli degilse)
# 10001 portuna response gonderilir
while true; 
do
    PACKET=$(nc -l 10000 ) 
    echo $PACKET
    IPADDR=$(echo $PACKET | cut -d ',' -f1)
    NICK=$(echo $PACKET | cut -d ',' -f2)
    
    echo "IP :  $IPADDR"
    echo "NICK: $NICK"
    echo "$MYIP,$MYNICK" |nc $IPADDR 10001 -w 1
    
    if grep "$IPADDR" AllUser.txt
        then
            echo "Ip adresi dosyada kayitli."
        else
            echo "Ip adresi dosyaya kaydedildi."
            echo "$IPADDR $NICK" >> AllUser.txt  
    fi
    
done



