# Gelen cevaplar dinlenir

MYNICK="HLYYLDZ"

while true;
do
    PACKET=$(nc -l 10001 ) 
    echo $PACKET
    IPADDR=$(echo $PACKET | cut -d ',' -f1)
    NICK=$(echo $PACKET | cut -d ',' -f2)
    
    echo "IP :  $IPADDR"
    echo "NICK: $NICK"
    echo "$MYIP,$MYNICK" |nc $IPADDR 10001 -w 1
    
    if grep "$IPADDR" AllUser.txt
        then
            echo "Ip adresi dosyada kayitli."
        else
            echo "Ip adresi dosyaya kaydedildi."
            echo "$IPADDR $NICK" >> AllUser.txt  
    fi
    
    #echo "IP :  $IPADDR"
    #echo "$MYNICK: mesaj" |nc $IPADDR 10002 -w 1
done
