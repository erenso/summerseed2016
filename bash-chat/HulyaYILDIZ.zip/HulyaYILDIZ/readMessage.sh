while true; do
    PACKET=$(nc -l 10002) 
    #echo $PACKET
    
    echo "******************************************************************"
    echo "NEW MESSAGE:"
    echo "$PACKET"
    echo ""
    echo "******************************************************************"
done
