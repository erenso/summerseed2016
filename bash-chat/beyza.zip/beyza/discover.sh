
F1=$(echo $1 | cut -d '.' -f1)
F2=$(echo $1 | cut -d '.' -f2)
F3=$(echo $1 | cut -d '.' -f3)
#Create subnet
IP="$F1.$F2.$F3."

#send_request
for i in {1..254}
	do
	   IP="$IP$i"
	   echo "IP: $IP"
	   echo "$1,$2" | nc $IP 10000 -w 1 &
	   IP="$F1.$F2.$F3."	
	done


