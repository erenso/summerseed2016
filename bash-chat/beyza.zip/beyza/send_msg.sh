
MYNICK="byzTS"
destIP=$( cat table.txt | grep "$1" | cut -d ',' -f1 )

	
echo "$MYNICK,$2" | nc destIP 10002


