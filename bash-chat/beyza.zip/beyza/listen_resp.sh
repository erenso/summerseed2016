
	#listen_resp
	PACKET=$(nc -l 10001)
	echo $PACKET

	IPADDR=$(echo $PACKET | cut -d ',' -f1)
	NICK=$(echo $PACKET | cut -d ',' -f2)
	
	if [ ! -f table.txt ];then
		touch table.txt
	fi

	if !(grep -cq "$IPADDR" table.txt)
	then
		echo "$IPADDR,$NICK" >> table.txt
	fi
	
	echo "respIP :  $IPADDR"
	echo "NICK: $NICK"


