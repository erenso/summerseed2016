
PACKET=$(nc -l 10002)
echo $PACKET

NICK=$(echo $PACKET | cut -d ',' -f1)
MSG=$(echo $PACKET | cut -d ',' -f2)

echo "**$NICK**  $MSG"
	
