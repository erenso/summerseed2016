
#Find myip
MYIP=$( ifconfig | grep "Bcast" | cut -d ':' -f2 | cut -d ' ' -f1 )
MYIP=$( echo "$MYIP" | cut -d ':' -f1)
echo "MYIP: $MYIP"
MYNICK="byzTS"

#backgroud exec

./discover.sh $MYIP $MYNICK &
BP1=$!
./listen_resp.sh &
BP2=$!
./listen_req.sh $MYIP $MYNICK &
BP3=$!
./listen_msg.sh
BP4=$!

echo "**********ONLINE**********"
cat table.txt
echo "write quit for exit"

while true; do

	echo "enter name:"
	read name

	if [ name="quit" ]; then
		break
	fi

	echo "enter message:"
	read msg

	./send_msg name msg
s
done

kill $BP1
kill $BP2
kill $BP3
kill $BP4
