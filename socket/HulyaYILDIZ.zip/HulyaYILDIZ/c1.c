#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int sockfd = 0, n = 0;
    char recvBuff[9995];
    struct sockaddr_in serv_addr; 
	struct timeval stop, start;


    memset(recvBuff, '0',sizeof(recvBuff));
	gettimeofday(&start, NULL);/*Client baslama zamani*/
    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Error : Could not create socket \n");
        return 1;
    } 

    memset(&serv_addr, '0', sizeof(serv_addr)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2])); 

	/*Verilen stringi (IP adresini) network adresine kopyalar*/
    if(inet_pton(AF_INET, argv[1], &serv_addr.sin_addr)<=0)
    {
        //printf("\n inet_pton error occured\n");
        return 1;
    } 

	/*Client server a baglanti yapar. Server kabul edene kadar bekler*/
    if( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
       //printf("\n Error : Connect Failed \n");
       return 1;
    } 


    snprintf(recvBuff, sizeof(recvBuff), "%s\\t",argv[3]);
    //printf("\n%s\n", recvBuff);
    //scanf("%s",recvBuff);
    while ( (n = write(sockfd, recvBuff, strlen(recvBuff))) < 0);
    //printf("\n%s\n", argv[3]);
    return 0;
}
