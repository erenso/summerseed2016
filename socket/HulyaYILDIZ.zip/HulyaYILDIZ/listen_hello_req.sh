#ifconfig komutu ile IP adresimizi sorguladik
MYIP=$(ifconfig|grep "Bcast:"|cut -d ':' -f2|cut -d ' ' -f1)
MYNICK="HLYYLDZ"

# Requestler dinlenir, cevap geldiginde IP ve nick kaydedilir(kayitli degilse)
# 10001 portuna response gonderilir
while true; 
do
    PACKET=$(./s1 10000 ) 
    #echo $PACKET
    IPADDR=$(echo $PACKET | cut -d ',' -f1)
    NICK=$(echo $PACKET | cut -d ',' -f2)
    
    #echo "IP :  $IPADDR"
    #echo "NICK: $NICK"
    #echo "$MYIP,$MYNICK" |nc $IPADDR 10001 -w 1
    ./c1 $temp 10001 "$MYIP,$MYNICK" &
    
    if grep "$IPADDR" AllUser.txt
        then
            echo ""
            #echo "Ip adresi dosyada kayitli."
        else
            #echo "Ip adresi dosyaya kaydedildi."
            echo "$IPADDR $NICK" >> AllUser.txt  
    fi
    
done



