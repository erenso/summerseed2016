# Gelen cevaplar dinlenir

MYNICK="HLYYLDZ"

while true;
do
    PACKET=$(./s1 10001 )
    #echo $PACKET
    IPADDR=$(echo $PACKET | cut -d ',' -f1)
    NICK=$(echo $PACKET | cut -d ',' -f2)
    
    #echo "IP :  $IPADDR"
    #echo "NICK: $NICK"
    
    if grep "$IPADDR" AllUser.txt
        then
            echo ""
            #echo "Ip adresi dosyada kayitli."
        else
            #echo "Ip adresi dosyaya kaydedildi."
            echo "$IPADDR $NICK" >> AllUser.txt  
    fi
    
    #echo "IP :  $IPADDR"
    #echo "$MYNICK: mesaj" |nc $IPADDR 10002 -w 1
done
