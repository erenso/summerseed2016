#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char main(int argc, char *argv[])
{
    int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr; 
    int i;
	
    char sendBuff[10000],send[10000];

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, ' ', sizeof(serv_addr));
    memset(sendBuff, ' ', sizeof(sendBuff)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(atoi(argv[1])); 

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    listen(listenfd, 10); 
	//fprintf(stderr, "Server was started\n");
	      
    connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);
    
    //scanf("%s",sendBuff);

    while( read(connfd, sendBuff, sizeof(sendBuff))<0); 
  
    
    for (i=0;i<10000;i++){
        if(sendBuff[i]=='\\' && sendBuff[i+1]=='t'){
            //printf("**********************************************");
            //printf( "%s\n",send);
            close(connfd);
            return *send;
         }
         else
            send[i] = sendBuff[i];
    }
     
    // printf( "%s\n",send);
    close(connfd);
return *send;    
}
