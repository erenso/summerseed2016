MYNICK="HLYYLDZ"

sh discover.sh
sh listen_hello_req.sh &
PID1=$!
sh listen_res.sh &
PID2=$!
sh readMessage.sh &
PID3=$!

# mesaj gonderilecek nick ve mesaj istenir. 
# QUIT nicki girildiginde program sonlanir
while true; do
    sleep 1
    echo "" 
    echo "Nick (enter QUIT for exit) : "
    read nick
       
    if [ $nick == "QUIT" ]; then
        echo "Chat sonlandırılıyor.."
        echo ""
        echo ""
        break
    else
        echo "Message : "   
        read sms 
    
    # nickin IP adresi dosyadan bulundu
    IP=$(echo $(cat AllUser.txt | grep " $nick"| cut -d ' ' -f1 ))

    # IP.ye mesaj gonderildi
        if grep $nick AllUser.txt
            then
                echo ""
                #echo "$MYNICK: $sms"| nc $IP 10002 -w 2
                ./c1 $IP 10002 "$MYNICK: $sms"
            else 
                echo ""
                echo "$nick isimli kullanici bulunamadi."
                echo ""
                echo ""
                echo ""
        fi         
    fi    
done


kill -9 $PID1
#echo "pid1" 
kill -9 $PID2
#echo "pid2" 
kill -9 $PID3
#echo "pid3" 
