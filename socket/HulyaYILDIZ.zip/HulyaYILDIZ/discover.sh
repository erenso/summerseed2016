#ifconfig komutu ile IP adresimizi sorguladik
MYIP=$(ifconfig|grep "Bcast:"|cut -d ':' -f2|cut -d ' ' -f1)
MYNICK="HLYYLDZ"
#echo "$MYIP"

# Ag adresini bulduk 
IP1=$(echo $MYIP | cut -d '.' -f1)
IP2=$(echo $MYIP | cut -d '.' -f2)
IP3=$(echo $MYIP | cut -d '.' -f3)
IPwireless=$IP1.$IP2.$IP3

AllIP=0

# Agdaki tum adreslere IP ve Nick gonderilir, timeout 1 sn.
for AllIP in {1..254}  
    do
        temp=$(echo "$IPwireless.$AllIP")
        #echo  $temp 
        #echo "$MYIP,$MYNICK" 
        #echo "$MYIP,$MYNICK" |nc $temp 10000 -w 1 &
        ./c1 $temp 10000 "$MYIP,$MYNICK" &
    done



