//netcat sender 
//netcat listender port vercez dinlicek
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 

#define queueLimit 4

/*struct in_addr {
	unsigned long s_addr;
	/* Internet address (32 bits) 
};*/

/*struct sockaddr_in
{
	unsigned short sin_family;
	/* Internet protocol (AF_INET) */
	//unsigned short sin_port;
	/* Address port (16 bits) */
	//struct in_addr sin_addr;
	/* Internet address (32 bits) */
	//char sin_zero[8];
	/* Not used 
};*/

char* main(int argc, char *argv[]){
	int status, s,i;
	int sockid,count,newSocket;
	int portNum;
	char recvBuf[255];

	struct sockaddr_in addrport;

	if (argc < 2) {
		 fprintf(stderr,"ERROR, ./exe PORTnumber\n");
		 exit(1);
    	}

	portNum = atoi(argv[1]);

	//int sockid= socket(family,type,protocol);
	sockid = socket(AF_INET, SOCK_STREAM, 0);

	if(sockid < 0){
		printf("socket not created.\n");
		exit(-1);
	}

	addrport.sin_family = AF_INET;
	addrport.sin_port = htons(portNum);///////////////////////****
	addrport.sin_addr.s_addr = htonl(INADDR_ANY);

	//assign the port to socket
	
	if(bind(sockid, (struct sockaddr *) &addrport, sizeof(addrport)) < 0){
		printf("not binding.\n");
		status = close(sockid);
		exit(-1);
	}

	//listen connections
	if(listen(sockid, queueLimit) < 0){//max listening time
		printf("not listening.\n");
		status = close(sockid);
		status = close(newSocket);
		exit(-1);

	}

	
	//connection accept
	newSocket = accept(sockid, (struct sockaddr *) NULL, NULL);
	if(newSocket < 0){
		printf("not accept.\n");
		status = close(sockid);
		exit(-1);	
	}
	
	
	//strng temizlemek gerek dongude	
	
	while(read(newSocket,&recvBuf[0],1) < 0);
	i = 1;
	//endofmesg char is \t
	while(1){
		read(newSocket,&recvBuf[i],1);	
		if(recvBuf[i] == '\\' )
		{
			++i;
			read(newSocket,&recvBuf[i],1);	
			if(recvBuf[i] == 't' ){
				recvBuf[i-1] = '\0';
				break;
			}
		}
		++i;
	}	

	printf("__%s\n",recvBuf);

	//port free	
	status = close(sockid);
	if(status < 0){
		printf("socket not closed.\n");
		exit(-1);		
	}	
	status = close(newSocket);
	if(status < 0){
		printf("newsocket not closed.\n");
		exit(-1);	
	}		
	
	return recvBuf;
}






