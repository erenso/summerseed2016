#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 

/*
struct in_addr {
	unsigned long s_addr;
	
}

struct
sockaddr_in
{
	unsigned short sin_family;
	
	unsigned short sin_port;
	
	struct in_addr sin_addr;

	char sin_zero[8];

}*/

int main(int argc, char *argv[]){
	int status, portNum,newid;
	struct sockaddr_in addrport;
	char msg[255];

	if (argc < 4) {
         fprintf(stderr,"ERROR, ./exe PORTnumber destIP mesg\n");
         exit(1);
    }

	portNum = atoi(argv[1]);
	//destIP = atoi(argv[2]);tipi ne nasil?

	//int sockid= socket(family,type,protocol);
	int sockid = socket(AF_INET, SOCK_STREAM, 0);
	if(sockid < 0){
		printf("socket not created.\n");
		return -1;
	}
	
	addrport.sin_family = AF_INET;
	addrport.sin_port = htons(portNum);///////////////////////****
	addrport.sin_addr.s_addr = inet_addr(argv[2]);//destination IP

	newid = connect(sockid, (struct sockaddr *) &addrport,sizeof(addrport));

	if(newid < 0){
		//printf("socket not connected.\n");
		status = close(newid);
		status = close(sockid);
		return -1;
	}
	

	/*
	printf("Enter message:\n");
	while(scanf("%s", msg) < 0);*/
	//strcpy(msg,argv[3]);
	strcat(argv[3],"\\t");

	while(write(sockid,argv[3],strlen(argv[3])) < 0);		
		
	
	//port free	
	status = close(newid);
	if(status < 0){
		printf("socket not closed.\n");
		return -1;	
	}	

	status = close(sockid);
	if(status < 0){
		printf("socket not closed.\n");
		return -1;	
	}	

	return 0;
}
