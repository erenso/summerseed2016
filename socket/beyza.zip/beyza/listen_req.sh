

	#listen_req
	#PACKET=$(nc -l 10000)
	PACKET=$(./listen 10000)
	echo $PACKET

	IPADDR=$(echo $PACKET | cut -d ',' -f1)
	NICK=$(echo $PACKET | cut -d ',' -f2)
	
	if [ ! -f table.txt ];then
		touch table.txt
	fi

	if !(grep -cq "$IPADDR" table.txt)
	then
		echo "$IPADDR,$NICK" >> table.txt
	fi

	echo "IP :  $IPADDR"
	echo "NICK: $NICK"
	

	#send_resp	
	./send 10001 $IPADDR "$1,$2"
	#echo "$1,$2" | nc $IPADDR 10001


